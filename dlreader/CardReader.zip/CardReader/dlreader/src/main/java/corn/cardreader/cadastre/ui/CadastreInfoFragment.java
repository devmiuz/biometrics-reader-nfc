package corn.cardreader.cadastre.ui;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import corn.cardreader.R;
import corn.cardreader.cadastre.CadastreDG1File;
import corn.cardreader.cadastre.CadastreListItem;
import corn.cardreader.model.BundleKey;
import corn.cardreader.storage.CadastreViewModel;

public class CadastreInfoFragment extends Fragment {

    protected static final String TAG = CadastreInfoFragment.class.getName();

    protected TextView objTypeTv;
    protected TextView areaCadNum;
    protected TextView buildingCadNum;
    protected TextView areaTv;
    protected TextView ownerTv;
    protected TextView passportInfoTv;
    protected TextView IDTv;
    protected TextView regInfoTv;
    protected TextView addressTv;
    protected TextView taxpayerTv;
    protected TextView legalFormTv;
    protected TextView ownershipPortionTv;
    protected TextView cadValueTv;
    protected TextView legalDocTv;


    private long cadastreID;
    private CadastreDG1File dg1File;
    private CadastreViewModel cadastreViewModel;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if(getArguments() != null){
            cadastreID = getArguments().getLong(BundleKey.CADASTRE_ID);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState) {
        View view =  inflater.inflate(R.layout.fragment_info_cadastre, parent, false);
        initUI(view);

        cadastreViewModel = ViewModelProviders.of(this).get(CadastreViewModel.class);
        cadastreViewModel.select(cadastreID).observe(this, new Observer<CadastreDG1File>() {
            @Override
            public void onChanged(@Nullable CadastreDG1File cadastreDG1File) {
                Log.d(TAG, "setting the cadastre");
                CadastreInfoFragment.this.setCadastre(cadastreDG1File);
            }
        });

        return view;
    }

    protected void initUI(View view) {
        objTypeTv = view.findViewById(R.id.object_type_tv);
        areaCadNum = view.findViewById(R.id.area_cadastre_num_tv);
        buildingCadNum = view.findViewById(R.id.building_cadastre_num_tv);
        areaTv = view.findViewById(R.id.area_tv);
        ownerTv = view.findViewById(R.id.owner_tv);
        passportInfoTv = view.findViewById(R.id.passport_tv);
        IDTv = view.findViewById(R.id.ID_num_tv);
        regInfoTv = view.findViewById(R.id.reg_date_num_tv);
        addressTv = view.findViewById(R.id.address_tv);
        taxpayerTv = view.findViewById(R.id.taxpayer_ID_tv);
        legalFormTv = view.findViewById(R.id.legal_form_tv);
        ownershipPortionTv = view.findViewById(R.id.property_portion_tv);
        cadValueTv = view.findViewById(R.id.cadastre_value_tv);
        legalDocTv = view.findViewById(R.id.legal_doc_tv);

        setCadastre(dg1File);
    }

    public void setCadastre(CadastreDG1File dg1File) {
        if(dg1File != null){
            objTypeTv.setText(dg1File.getObjtype());
            areaCadNum.setText(dg1File.getAreaCadNum());
            buildingCadNum.setText(dg1File.getBuildingCadNum());
            areaTv.setText(dg1File.getArea());
            ownerTv.setText(dg1File.getOwner());
            passportInfoTv.setText(dg1File.getPassportInfo());
            regInfoTv.setText(dg1File.getRegDateAndNum());
            addressTv.setText(dg1File.getAddress());
            taxpayerTv.setText(dg1File.getTaxpayer());
            legalFormTv.setText(dg1File.getLegalForm());
            ownershipPortionTv.setText(dg1File.getOwnershipPortion());
            cadValueTv.setText(dg1File.getCadValue());
            legalDocTv.setText(dg1File.getLegalDoc());
        }
    }

}

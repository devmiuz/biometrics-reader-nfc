package corn.cardreader.tech_card.util;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import corn.cardreader.R;
import corn.cardreader.ui.BaseNFCActivity;
import corn.cardreader.utilities.drivingLicense.DrivingLicenseReaderService;
import org.jmrtd.BACKey;
import org.jmrtd.BACKeySpec;

public class TechCardActivity extends BaseNFCActivity implements TechCardReaderDelegate {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tech_card);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);

        // TODO: 31/01/19 should be dynamic
        TechCardBACKey bacKey = new TechCardBACKey("01X013DB", "20181221", "AAF0417720");
        TechCardReaderService.parseIntent(intent, bacKey, this);
    }

    @Override
    public void onFinish() {

    }

    @Override
    public void onError(int errorID) {

    }
}

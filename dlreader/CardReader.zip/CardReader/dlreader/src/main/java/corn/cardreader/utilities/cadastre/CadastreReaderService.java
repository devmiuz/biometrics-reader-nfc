package corn.cardreader.utilities.cadastre;

import android.content.Intent;
import android.nfc.Tag;
import android.nfc.tech.IsoDep;
import android.os.AsyncTask;

import corn.cardreader.cadastre.CadastreDG1File;
import corn.cardreader.utilities.BaseReaderService;
import net.sf.scuba.smartcards.*;

import org.jmrtd.*;

import java.io.*;
import java.security.GeneralSecurityException;

import corn.cardreader.R;

// TODO: 24/01/19 refactor the class: make it more general
public class CadastreReaderService extends BaseReaderService {

    private static final String TAG = CadastreReaderService.class.getName();

    private static CadastreReaderDelegate readerDelegate;

    public static void parseIntent(Intent intent, CadastreReaderDelegate readerDelegate) {
        ERROR_CODE = NO_ERROR;
        CadastreReaderService.readerDelegate = readerDelegate;

        try{
            Tag tag = getTag(intent);
            new ReadTask(IsoDep.get(tag)).execute();
        }catch (IllegalArgumentException e){
            readerDelegate.onError(R.string.error_nfc_msg);
            e.printStackTrace();
        }
    }

    private static class ReadTask extends AsyncTask<Void, Void, Exception> {

        private IsoDep isoDep;

        private CadastreDG1File customDG1File;

        public ReadTask(IsoDep isoDep) {
            this.isoDep = isoDep;
        }

        @Override
        protected Exception doInBackground(Void... params) {
            CardService cardService = CardService.getInstance(isoDep);
            try {
                cardService.open();
                CadastreService drivingLicenseService = new CadastreService(cardService);
                drivingLicenseService.open();
                drivingLicenseService.sendSelectApplet();
                drivingLicenseService.doBAC();

                CadastreLDS lds = new CadastreLDS();

                CardFileInputStream dg1In = drivingLicenseService.getInputStream(PassportService.SF_DG1);
                lds.add(PassportService.EF_DG1, dg1In, dg1In.getLength());
                customDG1File = lds.getCustomDG1File();
            } catch (CardServiceException | IOException | GeneralSecurityException e) {
                e.printStackTrace();
                ERROR_CODE = R.string.error_nfc_msg;
            }

            return null;
        }

        @Override
        protected void onPostExecute(Exception result) {
            if (ERROR_CODE == NO_ERROR)
                readerDelegate.onFinish(customDG1File);
            else
                readerDelegate.onError(ERROR_CODE);
        }
    }
}

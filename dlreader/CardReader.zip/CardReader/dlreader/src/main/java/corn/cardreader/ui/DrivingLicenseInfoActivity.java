package corn.cardreader.ui;

import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.Bitmap;
import android.nfc.NfcAdapter;
import android.provider.Settings;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;
import corn.cardreader.R;
import corn.cardreader.model.BundleKey;
import corn.cardreader.model.dgFiles.DLicenseDG1File;
import corn.cardreader.model.dgFiles.DLicenseDG2File;
import corn.cardreader.utilities.drivingLicense.DLicenseReaderDelegate;
import corn.cardreader.utilities.drivingLicense.DrivingLicenseReaderService;
import org.jmrtd.BACKey;
import org.jmrtd.BACKeySpec;

// TODO: 16/01/19 use 28 target API for ButterKnife (implement)
// TODO: 23/01/19 saving the data to the memory
// TODO: 23/01/19 handle launching the activity on nfc detection
// TODO: 24/01/19 maybe progress bar should be changed
public class DrivingLicenseInfoActivity extends BaseNFCActivity implements DLicenseReaderDelegate {

    private static final String TAG = DrivingLicenseInfoActivity.class.getName();

    private BACKeySpec bacKeySpec;

    private ImageView userImageView;
    private ImageView signImageView;
    private TextView userNameTv;
    private TextView licenceNumTv;
    private TextView birthdayPlaceTv;
    private TextView birthDateTv;
    private TextView residenceTv;
    private TextView issuePlaceTv;
    private TextView issueDateTv;
    private TextView expireDateTv;
    private TextView categoryTv;

    private TextView textView;
    private LinearLayout progressBarLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);

        init();
    }

    private void init() {
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        String licenseNum = bundle.getString(BundleKey.LICENCE_NUM_KEY);
        String dateOfBirth = bundle.getString(BundleKey.DATE_OF_BIRTH_KEY);
        String dateOfExp = bundle.getString(BundleKey.DATE_OF_EXP_KEY);
        bacKeySpec = new BACKey(licenseNum, dateOfBirth, dateOfExp);

        initUI();
    }

    private void initUI() {
        userImageView = findViewById(R.id.user_image);
        signImageView = findViewById(R.id.sign_image);

        userNameTv = findViewById(R.id.user_name_main_tv);
        licenceNumTv = findViewById(R.id.licence_num_main_tv);
        birthDateTv = findViewById(R.id.birthdate_tv);
        birthdayPlaceTv = findViewById(R.id.birthplace_tv);

        residenceTv = findViewById(R.id.residence_tv);
        issuePlaceTv = findViewById(R.id.issue_place_tv);
        issueDateTv = findViewById(R.id.issue_date_tv);
        expireDateTv = findViewById(R.id.expiration_date_tv);
        categoryTv = findViewById(R.id.category_tv);

        textView = findViewById(R.id.progress_bar_tv);
        progressBarLayout = findViewById(R.id.linlaHeaderProgress);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        setIntent(intent);
        Log.d(TAG, "onNewIntent");

        progressBarLayout.setVisibility(View.VISIBLE);
        textView.setText(R.string.loading_text);

        DrivingLicenseReaderService.parseIntent(intent, bacKeySpec, this);
    }

    @Override
    public void onFinish() {
        progressBarLayout.setVisibility(View.GONE);
    }

    // TODO: 23/01/19 where should be country?
    @Override
    public void onDG1FileFinish(DLicenseDG1File customDG1File) {
        try{
            userNameTv.setText(customDG1File.getFullName());
            licenceNumTv.setText(customDG1File.getLicenceNumber());
            birthDateTv.setText(customDG1File.getDateOfBirth());
            issuePlaceTv.setText(customDG1File.getIssueState());
            issueDateTv.setText(customDG1File.getDateOfIssue());
            expireDateTv.setText(customDG1File.getDateOfExpiration());
            categoryTv.setText(customDG1File.getCategoriesAsString());
        }catch (NullPointerException e){
            Log.wtf(TAG, e.getMessage(), e);
            showError(R.string.error_nfc_msg);
        }
    }

    @Override
    public void onDG2FileFinish(DLicenseDG2File customDG2File) {
        try{
            birthdayPlaceTv.setText(customDG2File.getBirthPlace());
            residenceTv.setText(customDG2File.getResidenceAddress());
        }catch (NullPointerException e){
            Log.wtf(TAG, e.getMessage(), e);
            showError(R.string.error_nfc_msg);
        }
    }

    @Override
    public void onDG4FileFinish(Bitmap userImageBitmap) {
        try {
            userImageView.setImageBitmap(userImageBitmap);
        }catch (NullPointerException e){
            Log.wtf(TAG, e.getMessage(), e);
        }
    }

    @Override
    public void onDG5FileFinish(Bitmap signBitmap) {
        try {
            signImageView.setImageBitmap(signBitmap);
        }catch (NullPointerException e){
            Log.wtf(TAG, e.getMessage(), e);
        }
    }

    @Override
    public void onError(int errorID) {
        showError(errorID);

        Log.d(TAG, getResources().getString(errorID));

        if(errorID == R.string.auth_nfc_msg){
            finish();
        }

        textView.setText(R.string.insert_card_title);
    }
}

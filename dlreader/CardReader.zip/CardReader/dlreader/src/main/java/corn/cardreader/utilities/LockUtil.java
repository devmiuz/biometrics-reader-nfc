package corn.cardreader.utilities;

import android.os.Handler;

import com.github.orangegangsters.lollipin.lib.managers.LockManager;

public class LockUtil {

    static Handler timerHandler = new Handler();
    static Runnable timerRunnable = new Runnable() {
        @Override
        public void run() {
            LockManager.getInstance().getAppLock().setLastActiveMillis();
            timerHandler.postDelayed(this, 500);
        }
    };
}

package corn.cardreader.ui;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;

import com.github.orangegangsters.lollipin.lib.managers.LockManager;

import corn.cardreader.utilities.ContextWrapper;

import java.util.Locale;

public class App extends Application{

    @SuppressWarnings("unchecked")
    @Override
    public void onCreate() {
        super.onCreate();

        LockManager<CustomPinActivity> lockManager = LockManager.getInstance();
        lockManager.enableAppLock(this, CustomPinActivity.class);
        lockManager.getAppLock().setShouldShowForgot(false);

        //lockManager.getAppLock().setLogoId(R.drawable.security_lock);
    }

    @Override
    protected void attachBaseContext(Context base) {
        Locale locale = new Locale("uz");
        super.attachBaseContext(ContextWrapper.wrap(base, locale));
    }
}
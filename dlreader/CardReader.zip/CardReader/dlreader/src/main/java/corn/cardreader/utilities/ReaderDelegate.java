package corn.cardreader.utilities;

public interface ReaderDelegate {

    void onError(int errorID);
}

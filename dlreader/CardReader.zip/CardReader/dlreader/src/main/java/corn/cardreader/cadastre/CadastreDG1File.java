package corn.cardreader.cadastre;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;

@Entity(tableName = "cadastre")
public class CadastreDG1File {

    @PrimaryKey(autoGenerate = true)
    private long ID;
    private String objtype;
    private String areaCadNum;
    private String buildingCadNum;
    private String address;
    private String area;
    private String cadValue;
    private String regDateAndNum;
    private String owner;
    private String passportInfo;
    private String taxpayer;
    private String legalDoc;
    private String legalForm;
    private String ownershipPortion;

    @Ignore
    public CadastreDG1File(String objtype, String address, String cadValue) {
        this(objtype, "", "",
                address, "", cadValue, "",
                "", "", "", "",
                "", "");
    }

    public CadastreDG1File(String objtype, String areaCadNum,
                           String buildingCadNum, String address,
                           String area, String cadValue, String regDateAndNum,
                           String owner, String passportInfo,
                           String taxpayer, String legalDoc,
                           String legalForm, String ownershipPortion) {
        this.objtype = objtype;
        this.areaCadNum = areaCadNum;
        this.buildingCadNum = buildingCadNum;
        this.address = address;
        this.area = area;
        this.cadValue = cadValue;
        this.regDateAndNum = regDateAndNum;
        this.owner = owner;
        this.passportInfo = passportInfo;
        this.taxpayer = taxpayer;
        this.legalDoc = legalDoc;
        this.legalForm = legalForm;
        this.ownershipPortion = ownershipPortion;
    }

    public String getObjtype() {
        return objtype;
    }

    public void setObjtype(String objtype) {
        this.objtype = objtype;
    }

    public String getAreaCadNum() {
        return areaCadNum;
    }

    public void setAreaCadNum(String areaCadNum) {
        this.areaCadNum = areaCadNum;
    }

    public String getBuildingCadNum() {
        return buildingCadNum;
    }

    public void setBuildingCadNum(String buildingCadNum) {
        this.buildingCadNum = buildingCadNum;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getCadValue() {
        return cadValue;
    }

    public void setCadValue(String cadValue) {
        this.cadValue = cadValue;
    }

    public String getRegDateAndNum() {
        return regDateAndNum;
    }

    public void setRegDateAndNum(String regDateAndNum) {
        this.regDateAndNum = regDateAndNum;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getPassportInfo() {
        return passportInfo;
    }

    public void setPassportInfo(String passportInfo) {
        this.passportInfo = passportInfo;
    }

    public String getTaxpayer() {
        return taxpayer;
    }

    public void setTaxpayer(String taxpayer) {
        this.taxpayer = taxpayer;
    }

    public String getLegalDoc() {
        return legalDoc;
    }

    public void setLegalDoc(String legalDoc) {
        this.legalDoc = legalDoc;
    }

    public String getLegalForm() {
        return legalForm;
    }

    public void setLegalForm(String legalForm) {
        this.legalForm = legalForm;
    }

    public String getOwnershipPortion() {
        return ownershipPortion;
    }

    public void setOwnershipPortion(String ownershipPortion) {
        this.ownershipPortion = ownershipPortion;
    }

    public long getID() {
        return ID;
    }

    public void setID(long ID) {
        this.ID = ID;
    }
}

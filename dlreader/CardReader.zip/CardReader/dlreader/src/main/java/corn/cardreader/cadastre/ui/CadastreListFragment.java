package corn.cardreader.cadastre.ui;


import android.app.Activity;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import corn.cardreader.R;
import corn.cardreader.cadastre.CadastreDG1File;
import corn.cardreader.cadastre.CadastreListAdapter;
import corn.cardreader.cadastre.CadastreListItem;
import corn.cardreader.listener.OnItemClickListener;
import corn.cardreader.model.BundleKey;
import corn.cardreader.storage.CadastreViewModel;

import java.util.ArrayList;
import java.util.List;

public class CadastreListFragment extends Fragment implements OnItemClickListener {

    private CadastreListAdapter adapter;
    private LinearLayoutManager layoutManager;

    private CadastreViewModel cadastreViewModel;

    private static final String TAG = CadastreListFragment.class.getName();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_cadastre_list, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        RecyclerView rvContacts = view.findViewById(R.id.cadastre_recycler_view);


        adapter = new CadastreListAdapter(this);
        rvContacts.setAdapter(adapter);
        layoutManager = new LinearLayoutManager(getContext());
        rvContacts.setLayoutManager(layoutManager);

        populate();
    }

    private void populate() {
        cadastreViewModel = ViewModelProviders.of(this).get(CadastreViewModel.class);
        cadastreViewModel.getAllWords().observe(this, cadastreDG1Files -> {
            Log.d(TAG, "onChanged " + cadastreDG1Files.size());
            adapter.setCadastres(new ArrayList<>(cadastreDG1Files));
            layoutManager.scrollToPosition(0);
        });
    }

    @Override
    public void onItemClick(CadastreListItem item) {
        if(item.getID() == CadastreListAdapter.ADD_ITEM){
            Intent intent = new Intent(getActivity(), CadastreAddActivity.class);
            startActivity(intent);
        }else{
            Intent intent = new Intent(getActivity(), CadastreInfoActivity.class);
            intent.putExtra(BundleKey.CADASTRE_ID, item.getID());
            startActivity(intent);
        }
    }

    // TODO: 04/02/19 maybe only one popup menu is needed
    @Override
    public void onMoreClick(CadastreListItem item, View view) {
        PopupMenu popup = new PopupMenu(getActivity(), view);
        popup.getMenuInflater()
                .inflate(R.menu.cadastre_popup_menu, popup.getMenu());

        popup.setOnMenuItemClickListener(menuItem -> {
            if(menuItem.getItemId() == R.id.delete_cadastre){
                cadastreViewModel.delete(item.getID());
            }

            return true;
        });

        popup.show();
    }

    public ArrayList<CadastreListItem> getCadastres(){
        return adapter.getCadastres();
    }
}

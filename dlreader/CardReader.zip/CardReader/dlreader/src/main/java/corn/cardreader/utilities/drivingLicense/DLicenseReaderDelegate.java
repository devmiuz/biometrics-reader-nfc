package corn.cardreader.utilities.drivingLicense;

import android.graphics.Bitmap;
import corn.cardreader.model.dgFiles.DLicenseDG1File;
import corn.cardreader.model.dgFiles.DLicenseDG2File;
import corn.cardreader.utilities.ReaderDelegate;

public interface DLicenseReaderDelegate extends ReaderDelegate {

    void onFinish();
    void onDG1FileFinish(DLicenseDG1File customDG1File);
    void onDG2FileFinish(DLicenseDG2File customDG2File);
    void onDG4FileFinish(Bitmap userImageBitmap);
    void onDG5FileFinish(Bitmap signBitmap);
}

package corn.cardreader.storage;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;
import android.util.Log;
import corn.cardreader.cadastre.CadastreDG1File;

@Database(entities = {CadastreDG1File.class}, version = 1)
public abstract class CadastreRoomDB extends RoomDatabase {

    private static final String DB_NAME = "db";
    private static volatile CadastreRoomDB instance;

    static CadastreRoomDB getDatabase(final Context context) {
        Log.d("CadastreRoomDB", "getDatabase");
        if (instance == null) {
            Log.d("CadastreRoomDB", "db instance = null");
            synchronized (CadastreRoomDB.class) {
                if (instance == null) {
                    instance = Room.databaseBuilder(context.getApplicationContext(),
                            CadastreRoomDB.class, DB_NAME)
                            .build();
                }
            }
        }

        return instance;
    }

    public abstract CadastreDAO getCadastreDAO();
}

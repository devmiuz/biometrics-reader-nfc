package corn.cardreader.ui;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.github.orangegangsters.lollipin.lib.managers.AppLock;
import com.github.orangegangsters.lollipin.lib.managers.LockManager;

import java.util.Locale;

import corn.cardreader.utilities.ContextWrapper;

public class BaseActivity extends AppCompatActivity {

    protected static final int REQUEST_CODE_ENABLE = 11;
    private static final String TAG = "BASE";

    private static long lastActiveTime = 0;
    private static boolean isFirstRun = true;
    private static boolean showedPinActivity = false;

    @Override
    protected void attachBaseContext(Context base) {
        Locale locale = new Locale("uz");
        super.attachBaseContext(ContextWrapper.wrap(base, locale));
    }

    @Override
    protected void onResume() {
        super.onResume();

        Log.d(TAG, "onResume");

        long currentTimeMillis = System.currentTimeMillis();

        if (isFirstRun) {
            Log.d(TAG, "isFirstRun = true");
            isFirstRun = false;
            showLockScreen();
        } else if (!showedPinActivity) {
            if (currentTimeMillis - lastActiveTime > 4000){
                Log.d(TAG, "> 4000 ms");
                Log.d(TAG, "lastActiveTime " + lastActiveTime);
                Log.d(TAG, "currentTime " + currentTimeMillis);
                Log.d(TAG, "difference " + (currentTimeMillis - lastActiveTime));
                lastActiveTime = currentTimeMillis;
                showLockScreen();
            }
        }
    }

    protected void showLockScreen() {
        Intent intent = new Intent(this, CustomPinActivity.class);
        if (LockManager.getInstance().getAppLock().isPasscodeSet()) {
            intent.putExtra(AppLock.EXTRA_TYPE, AppLock.UNLOCK_PIN);
        } else {
            intent.putExtra(AppLock.EXTRA_TYPE, AppLock.ENABLE_PINLOCK);
        }
        startActivityForResult(intent, BaseActivity.REQUEST_CODE_ENABLE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Log.d(TAG, "onActivityResult");

        if (requestCode == REQUEST_CODE_ENABLE){
            showedPinActivity = true;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();

        Log.d(TAG, "onPause");
        lastActiveTime = System.currentTimeMillis();
        Log.d(TAG, "lastActiveTime " + lastActiveTime);

        showedPinActivity = false;
    }
}
package corn.cardreader.cadastre.ui;

import android.app.PendingIntent;
import android.content.Intent;
import android.nfc.NfcAdapter;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.widget.Toast;
import corn.cardreader.R;
import corn.cardreader.ui.BaseActivity;
import corn.cardreader.ui.BaseNFCActivity;

public class CadastreAddActivity extends BaseNFCActivity {

    private static final String TAG = CadastreAddActivity.class.getName();

    private CadastreAddFragment cadastreFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastre);

        initUI();
    }

    private void initUI() {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        cadastreFragment = new CadastreAddFragment();
        fragmentTransaction.add(R.id.content_fragment, cadastreFragment);

        fragmentTransaction.commit();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        cadastreFragment.processIntent(intent);
    }
}

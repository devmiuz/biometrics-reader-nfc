package corn.cardreader.cadastre;

import java.io.Serializable;

public class CadastreListItem implements Serializable {

    private long ID;
    private String objType;
    private String address;
    private String cadastreNum;

    public CadastreListItem(long id, String objType, String address, String cadastreNum) {
        ID = id;
        this.objType = objType;
        this.address = address;
        this.cadastreNum = cadastreNum;
    }

    public String getObjType() {
        return objType;
    }

    public void setObjType(String objType) {
        this.objType = objType;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCadastreNum() {
        return cadastreNum;
    }

    public void setCadastreNum(String cadastreNum) {
        this.cadastreNum = cadastreNum;
    }

    public long getID() {
        return ID;
    }

    public void setID(long ID) {
        this.ID = ID;
    }

    @Override
    public String toString() {
        return ID + " " + objType + " " + address + " " + cadastreNum;
    }
}

package corn.cardreader.utilities.cadastre;

import corn.cardreader.cadastre.CadastreDG1File;
import corn.cardreader.utilities.BaseLDS;
import org.apache.commons.io.IOUtils;
import org.jmrtd.PassportService;

import java.io.IOException;
import java.io.InputStream;

public class CadastreLDS extends BaseLDS {

    private static final String TAG = CadastreLDS.class.getName();

    public CadastreDG1File getCustomDG1File() throws IOException {
        byte[] response = getResponseBytes(PassportService.EF_DG1);
        return CadastreMRZUtil.parseDG1(response);
    }

    public byte[] getResponseBytes(final short fileID) throws IOException {
        InputStream is = getInputStream(fileID);
        byte[] response = IOUtils.toByteArray(is);
        return response;
    }
}

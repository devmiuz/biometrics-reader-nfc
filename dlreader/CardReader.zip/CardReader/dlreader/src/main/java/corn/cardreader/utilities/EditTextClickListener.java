package corn.cardreader.utilities;

import android.app.DatePickerDialog;
import android.content.Context;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;

import java.util.Calendar;

public class EditTextClickListener implements View.OnClickListener {

    private static final String TAG = EditTextClickListener.class.getName();

    private DatePickerListener pickerListener;
    private Calendar calendar;

    private Context context;

    public EditTextClickListener(Context context, int editTextID, DatePickerDelegate datePickerDelegate){
        this.context = context;
        pickerListener = new DatePickerListener(editTextID, datePickerDelegate);
        calendar = Calendar.getInstance();
    }

    @Override
    public void onClick(View v) {

        new DatePickerDialog(context, pickerListener, calendar
                .get(Calendar.YEAR), calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)).show();
    }

    class DatePickerListener implements DatePickerDialog.OnDateSetListener {

        private int editTextID;
        private DatePickerDelegate listener;

        public DatePickerListener(int editTextID, DatePickerDelegate listener){
            this.editTextID = editTextID;
            this.listener = listener;
        }

        @Override
        public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
            listener.updateDate(editTextID, year, month + 1, dayOfMonth);
            calendar.set(year, month, dayOfMonth);
        }
    }

}

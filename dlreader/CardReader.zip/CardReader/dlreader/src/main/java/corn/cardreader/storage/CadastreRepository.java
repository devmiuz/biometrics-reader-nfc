package corn.cardreader.storage;

import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.os.AsyncTask;
import corn.cardreader.cadastre.CadastreDG1File;

import java.util.ArrayList;
import java.util.List;

public class CadastreRepository {

    private CadastreDAO mWordDao;
    private LiveData<List<CadastreDG1File>> mAllWords;

    CadastreRepository(Application application) {
        CadastreRoomDB db = CadastreRoomDB.getDatabase(application);
        mWordDao = db.getCadastreDAO();
        mAllWords = mWordDao.loadAllCadastres();
    }

    LiveData<List<CadastreDG1File>> getAllWords() {
        return mAllWords;
    }

    public LiveData<CadastreDG1File> select(long ID){
        return mWordDao.selectByCadastreByID(ID);
    }

    public void insert (CadastreDG1File cadastreDG1File) {
        new insertAsyncTask(mWordDao).execute(cadastreDG1File);
    }

    public void delete(long ID){
        new deleteAsyncTask(mWordDao).execute(ID);
    }

    private static class insertAsyncTask extends AsyncTask<CadastreDG1File, Void, Void> {

        private CadastreDAO mAsyncTaskDao;

        insertAsyncTask(CadastreDAO dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(final CadastreDG1File... params) {
            mAsyncTaskDao.insert(params[0]);
            return null;
        }
    }

    private static class deleteAsyncTask extends AsyncTask<Long, Void, Void> {
        private CadastreDAO mAsyncTaskDao;

        deleteAsyncTask(CadastreDAO dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(Long... params) {
            mAsyncTaskDao.delete(params[0]);
            return null;
        }
    }
}
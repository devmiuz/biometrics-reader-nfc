package corn.cardreader.ui;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;
import corn.cardreader.R;
import corn.cardreader.model.BundleKey;
import corn.cardreader.utilities.DateTextWatcher;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

// TODO: 25/01/19 info button for every field
public class InputActivity extends BaseActivity{

    private static final String TAG = InputActivity.class.getName();

    private EditText licenseEditText;
    private EditText birthEditText;
    private EditText expireEditText;

    private DateTextWatcher birthDateWatcher;
    private DateTextWatcher expireDateWatcher;

    private String licenseNum;
    private String birthDate = "";
    private String expireDate = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input);

        init();
    }

    // TODO: 24/01/19 masked edit text for license number
    private void init() {
        licenseEditText = findViewById(R.id.licence_num_edit_text);
        birthEditText = findViewById(R.id.birthdate_edit_text);
        expireEditText = findViewById(R.id.expiration_date_edit_text);

        birthDateWatcher = new DateTextWatcher(birthEditText);
        birthEditText.addTextChangedListener(birthDateWatcher);
        expireDateWatcher = new DateTextWatcher(expireEditText);
        expireEditText.addTextChangedListener(expireDateWatcher);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.input_activity_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.done_action){
            if(isValidInout()){
                licenseNum = licenseNum.toUpperCase();
                Log.d(TAG, licenseNum + " " + birthDate + " " + expireDate);
                showMainActivity();
            }else{
                Toast.makeText(this, R.string.fill_gaps_msg, Toast.LENGTH_SHORT).show();
            }
        }

        return true;
    }

    private void showMainActivity() {
        Intent intent = new Intent(this, DrivingLicenseInfoActivity.class);

        Bundle bundle = new Bundle();
        bundle.putString(BundleKey.LICENCE_NUM_KEY, licenseNum);
        bundle.putString(BundleKey.DATE_OF_BIRTH_KEY, birthDate);
        bundle.putString(BundleKey.DATE_OF_EXP_KEY, expireDate);

        intent.putExtras(bundle);

        startActivity(intent);
    }

    private boolean isValidInout() {
        licenseNum = licenseEditText.getText().toString().trim();
        if(licenseNum.isEmpty())
            return false;

        if(licenseNum.length() !=  9)
            return false;

        if(birthDateWatcher.getCurrent().length() < 8)
            return false;

        if(expireDateWatcher.getCurrent().length() < 8)
            return false;

        try {
            SimpleDateFormat editTextFormat = new SimpleDateFormat("dd/MM/yyyy");
            SimpleDateFormat format = new SimpleDateFormat("yyMMdd");
            Date date = null;
            date = editTextFormat.parse(birthDateWatcher.getCurrent());
            birthDate = format.format(date);
            date = editTextFormat.parse(expireDateWatcher.getCurrent());
            expireDate = format.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
            return false;
        }

        return true;
    }
}

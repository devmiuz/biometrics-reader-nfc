package corn.cardreader.storage;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import corn.cardreader.cadastre.CadastreDG1File;

import java.util.List;

public class CadastreViewModel extends AndroidViewModel {

    private CadastreRepository mRepository;

    private LiveData<List<CadastreDG1File>> mAllWords;

    public CadastreViewModel(Application application) {
        super(application);
        mRepository = new CadastreRepository(application);
        mAllWords = mRepository.getAllWords();
    }

    public LiveData<List<CadastreDG1File>> getAllWords() {
        return mAllWords;
    }

    public void insert(CadastreDG1File word) { mRepository.insert(word); }

    public void delete(long ID){
        mRepository.delete(ID);
    }

    public LiveData<CadastreDG1File> select(long ID){
        return mRepository.select(ID);
    }
}
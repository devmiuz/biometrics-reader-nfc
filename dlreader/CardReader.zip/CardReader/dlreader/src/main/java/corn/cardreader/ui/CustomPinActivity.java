package corn.cardreader.ui;

import android.content.Intent;
import android.util.Log;

import com.github.orangegangsters.lollipin.lib.managers.AppLock;
import com.github.orangegangsters.lollipin.lib.managers.AppLockActivity;
import com.github.orangegangsters.lollipin.lib.managers.LockManager;

public class CustomPinActivity extends AppLockActivity {

    private static final String TAG = CustomPinActivity.class.getName();

    @Override
    public void showForgotDialog() {}

    @Override
    public void onPinFailure(int i) {}

    @Override
    public void onPinSuccess(int i) {}

    @Override
    public int getPinLength() {
        return super.getPinLength();
    }
}

package corn.cardreader.utilities.cadastre;

import corn.cardreader.cadastre.CadastreDG1File;
import corn.cardreader.utilities.ReaderDelegate;

public interface CadastreReaderDelegate extends ReaderDelegate {

    void onFinish(CadastreDG1File dg1File);
}

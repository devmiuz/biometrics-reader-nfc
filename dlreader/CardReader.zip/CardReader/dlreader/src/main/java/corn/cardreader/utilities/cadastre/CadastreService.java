package corn.cardreader.utilities.cadastre;

import android.util.Log;
import corn.cardreader.model.BACCalculator;
import corn.cardreader.utilities.BaseService;
import net.sf.scuba.smartcards.APDUEvent;
import net.sf.scuba.smartcards.CardService;
import net.sf.scuba.smartcards.CardServiceException;
import net.sf.scuba.util.Hex;
import org.jmrtd.BACKeySpec;
import org.jmrtd.PassportService;
import org.jmrtd.lds.MRZInfo;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;

public class CadastreService extends BaseService {

    private static final String TAG = CadastreService.class.getName();

    public CadastreService(CardService service) throws CardServiceException {
        super(service);
    }

    public void doBAC() throws CardServiceException, GeneralSecurityException{
        String mrzInfo = "GID_KADASTR_KEY1";

        byte[] bytes = mrzInfo.getBytes(StandardCharsets.US_ASCII);

        doBAC(bytes);
    }
}
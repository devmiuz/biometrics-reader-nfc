package corn.cardreader.cadastre;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import corn.cardreader.R;
import corn.cardreader.listener.OnItemClickListener;

import java.util.ArrayList;

public class CadastreListAdapter extends RecyclerView.Adapter<CadastreListAdapter.ViewHolder> {

    public static final int ADD_ITEM = -1;
    private static final String TAG = CadastreListAdapter.class.getName();

    private ArrayList<CadastreListItem> cadastres;
    private OnItemClickListener listener;

    public CadastreListAdapter(OnItemClickListener listener) {
        this(new ArrayList<>(), listener);
    }

    public CadastreListAdapter(ArrayList<CadastreListItem> cadastres, OnItemClickListener listener) {
        this.cadastres = cadastres;
        this.listener = listener;
    }

    public void setCadastres(ArrayList<CadastreDG1File> dg1Files) {
        int currentSize = cadastres.size();
        cadastres.clear();

        for (CadastreDG1File dg1File : dg1Files)
            cadastres.add(new CadastreListItem(dg1File.getID(), dg1File.getObjtype(), dg1File.getAddress(), dg1File.getCadValue()));

        notifyItemRangeRemoved(0, currentSize);
        notifyItemRangeInserted(0, cadastres.size());

        addDefaultAddLayout();
    }

    private void addDefaultAddLayout() {
        cadastres.add(new CadastreListItem(-1, "", "", ""));
        notifyItemInserted(cadastres.size() - 1);
    }

    @Override
    public int getItemViewType(int position) {
        return (int) cadastres.get(position).getID();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);

        View contactView;
        if (viewType == ADD_ITEM) {
            contactView = inflater.inflate(R.layout.add_cadastre_card, parent, false);
        } else {
            contactView = inflater.inflate(R.layout.cadastre_card, parent, false);
        }

        ViewHolder viewHolder = new ViewHolder(contactView);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        CadastreListItem contact = cadastres.get(position);
        holder.bind(contact, listener);
    }

    @Override
    public int getItemCount() {
        return cadastres.size();
    }

    public ArrayList<CadastreListItem> getCadastres() {
        ArrayList<CadastreListItem> items = new ArrayList<>(cadastres.subList(0, cadastres.size() - 1));
        return items;
    }

    public void addCadastre(CadastreListItem cadastre) {
        cadastres.add(0, cadastre);
        notifyItemInserted(0);
    }

    // TODO: 04/02/19 refactor the class
    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private TextView objTypeTv;
        private TextView address;
        private TextView cadastreNum;

        private OnItemClickListener listener;
        private CadastreListItem cadastre;

        private ImageButton moreBtn;

        public ViewHolder(View itemView) {
            super(itemView);

            objTypeTv = itemView.findViewById(R.id.object_type_tv);
            address = itemView.findViewById(R.id.address_tv);
            cadastreNum = itemView.findViewById(R.id.cadastre_num_tv);
            moreBtn = itemView.findViewById(R.id.cadastre_more_btn);
            LinearLayout layout = itemView.findViewById(R.id.main_layout);

            if (layout != null) {
                layout.setOnClickListener(this);
                moreBtn.setOnClickListener(this);
            }else{
                itemView.setOnClickListener(this);
            }
        }

        // TODO: 04/02/19 maybe there is no need for null check
        @Override
        public void onClick(View v) {
            if (v.getId() == R.id.cadastre_more_btn)
                listener.onMoreClick(cadastre, v);
            else
                listener.onItemClick(cadastre);
        }

        public void bind(CadastreListItem cadastre, OnItemClickListener listener) {
            this.listener = listener;
            this.cadastre = cadastre;

            try {
                objTypeTv.setText(cadastre.getObjType());
                address.setText(cadastre.getAddress());
                cadastreNum.setText(cadastre.getCadastreNum());
            } catch (NullPointerException e) {
            }
        }
    }
}

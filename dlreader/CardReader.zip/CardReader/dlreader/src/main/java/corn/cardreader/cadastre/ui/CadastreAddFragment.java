package corn.cardreader.cadastre.ui;

import android.app.Activity;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.*;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import corn.cardreader.R;
import corn.cardreader.cadastre.CadastreDG1File;
import corn.cardreader.cadastre.CadastreListItem;
import corn.cardreader.model.BundleKey;
import corn.cardreader.storage.CadastreViewModel;
import corn.cardreader.utilities.cadastre.CadastreReaderDelegate;
import corn.cardreader.utilities.cadastre.CadastreReaderService;

public class CadastreAddFragment extends CadastreInfoFragment implements CadastreReaderDelegate, View.OnClickListener {

    private static final String TAG = CadastreAddFragment.class.getName();

    private TextView textView;
    private LinearLayout progressBarLayout;

    private View doneLayout;
    private Button btn;

    private CadastreDG1File dg1File;
    private CadastreViewModel cadastreViewModel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState) {
        cadastreViewModel = ViewModelProviders.of(this).get(CadastreViewModel.class);

        return inflater.inflate(R.layout.fragment_add_cadastre, parent, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        initUI(view);
    }

    protected void initUI(View view) {
        super.initUI(view);

        btn = view.findViewById(R.id.reg_btn);
        btn.setOnClickListener(this);
        btn.setVisibility(View.GONE);
        doneLayout = view.findViewById(R.id.reg_done_layout);

        textView = view.findViewById(R.id.progress_bar_tv);
        progressBarLayout = view.findViewById(R.id.linlaHeaderProgress);

        progressBarLayout.setVisibility(View.VISIBLE);
    }

    public void processIntent(Intent intent) {
        progressBarLayout.setVisibility(View.VISIBLE);
        textView.setText(R.string.loading_text);

        CadastreReaderService.parseIntent(intent, this);
    }

    @Override
    public void onFinish(CadastreDG1File dg1File) {
        try {
            setCadastre(dg1File);

            this.dg1File = dg1File;

            progressBarLayout.setVisibility(View.GONE);
            btn.setVisibility(View.VISIBLE);
        } catch (NullPointerException e) {
            Log.wtf(TAG, e.getMessage(), e);
            showError(R.string.error_nfc_msg);
        }
    }

    private void showError(int errorID) {
        Toast.makeText(getContext(), errorID, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onError(int errorID) {
        showError(errorID);
        textView.setText(R.string.insert_card_title);
    }

    @Override
    public void onClick(View v) {

        doneLayout.setVisibility(View.VISIBLE);

        Handler handler = new Handler();
        handler.postDelayed(() -> doneLayout.setVisibility(View.GONE), 1500);

        btn.setVisibility(View.GONE);

        // TODO: 30/01/19 show progress bar until the process is finished
        // TODO: 04/02/19 maybe the listen should be added for the insertion

        cadastreViewModel.insert(dg1File);

        Intent intent = new Intent();
        getActivity().setResult(Activity.RESULT_OK, intent);
        getActivity().finish();
    }
}

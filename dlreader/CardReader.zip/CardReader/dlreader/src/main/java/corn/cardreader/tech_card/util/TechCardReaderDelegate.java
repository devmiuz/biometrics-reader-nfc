package corn.cardreader.tech_card.util;

import corn.cardreader.utilities.ReaderDelegate;

public interface TechCardReaderDelegate extends ReaderDelegate {

    void onFinish();
}

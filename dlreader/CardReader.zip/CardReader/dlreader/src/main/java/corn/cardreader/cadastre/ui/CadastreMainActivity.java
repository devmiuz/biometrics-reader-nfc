package corn.cardreader.cadastre.ui;

import android.support.v4.app.FragmentManager;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import corn.cardreader.R;
import corn.cardreader.cadastre.CadastreListItem;
import corn.cardreader.model.BundleKey;
import corn.cardreader.ui.BaseActivity;
import corn.cardreader.payment.PaymentMainFragment;

import java.util.ArrayList;

public class CadastreMainActivity extends BaseActivity implements NavigationView.OnNavigationItemSelectedListener {

    private static final String TAG = CadastreMainActivity.class.getName();

    private DrawerLayout dl;
    private ActionBarDrawerToggle t;
    private NavigationView nv;

    private FragmentManager fragmentManager;
    private CadastreListFragment cadastreListFragment;
    private PaymentMainFragment paymentMainFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_cadastre);

        init();
    }

    private void init() {
        dl = findViewById(R.id.drawer_layout);
        t = new ActionBarDrawerToggle(this, dl, R.string.open, R.string.close);

        dl.addDrawerListener(t);
        t.syncState();

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        nv = findViewById(R.id.nv);
        nv.setNavigationItemSelectedListener(this);
        nv.bringToFront();

        initUI();
    }

    private void initUI() {
        fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        cadastreListFragment = new CadastreListFragment();
        paymentMainFragment = new PaymentMainFragment();

        fragmentTransaction.add(R.id.content_fragment, cadastreListFragment);
        fragmentTransaction.addToBackStack(null);

        fragmentTransaction.commit();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(t.onOptionsItemSelected(item))
            return true;

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if(id == R.id.cards_menu_item)
            return true;

        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        switch(id) {
            case R.id.cadastres_menu_item:
                fragmentTransaction.replace(R.id.content_fragment, cadastreListFragment);
                break;
            case R.id.payment_menu_item:
                paymentMainFragment.setCadastres(cadastreListFragment.getCadastres());
                fragmentTransaction.replace(R.id.content_fragment, paymentMainFragment);
                break;
        }

        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();

        dl.closeDrawer(Gravity.LEFT);

        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();

        dl.closeDrawer(Gravity.LEFT);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        finish();
    }
}

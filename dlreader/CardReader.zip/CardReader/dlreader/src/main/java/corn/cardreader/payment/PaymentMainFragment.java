package corn.cardreader.payment;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import corn.cardreader.R;
import corn.cardreader.cadastre.CadastreListItem;
import corn.cardreader.model.BundleKey;

import java.util.ArrayList;

// TODO: 08/02/19 handle no card situation
// TODO: 08/02/19 no option menu in the card
// TODO: 08/02/19 card size should be relative to the screen size
public class PaymentMainFragment extends Fragment {

    ArrayList<CadastreListItem> cadastres = new ArrayList<>();
    LayoutInflater inflater;    //Used to create individual pages
    ViewPager vp;               //Reference to class to swipe views

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_payment_main, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        inflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        vp = view.findViewById(R.id.view_pager);
        vp.setAdapter(new MyPagesAdapter());
    }

    public void setCadastres(ArrayList<CadastreListItem> cadastres){
        this.cadastres.clear();
        this.cadastres.addAll(cadastres);
    }

    class MyPagesAdapter extends PagerAdapter {
        @Override
        public int getCount() {
            return cadastres.size();
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            View page = inflater.inflate(R.layout.cadastre_card, null);

            TextView addressTv, cadastreNumTv, objTypeTv;

            addressTv = page.findViewById(R.id.address_tv);
            cadastreNumTv = page.findViewById(R.id.cadastre_num_tv);
            objTypeTv = page.findViewById(R.id.object_type_tv);

            ImageButton btn = page.findViewById(R.id.cadastre_more_btn);
            btn.setVisibility(View.GONE);

            CadastreListItem item = cadastres.get(position);

            addressTv.setText(item.getAddress());
            cadastreNumTv.setText(item.getCadastreNum());
            objTypeTv.setText(item.getObjType());

            container.addView(page, 0);

            return page;
        }

        @Override
        public boolean isViewFromObject(View arg0, Object arg1) {
            //See if object from instantiateItem is related to the given view
            //required by API
            return arg0 == (View) arg1;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((View) object);
            object = null;
        }
    }
}

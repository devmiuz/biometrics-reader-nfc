package corn.cardreader.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import com.github.orangegangsters.lollipin.lib.PinActivity;
import com.github.orangegangsters.lollipin.lib.managers.AppLock;
import com.github.orangegangsters.lollipin.lib.managers.LockManager;

import corn.cardreader.R;
import corn.cardreader.cadastre.ui.CadastreMainActivity;
import corn.cardreader.tech_card.util.TechCardActivity;
import corn.cardreader.utilities.ContextWrapper;

import java.security.Security;
import java.util.Locale;

public class MainActivity extends BaseActivity implements View.OnClickListener {

    static {
        Security.insertProviderAt(new org.spongycastle.jce.provider.BouncyCastleProvider(), 1);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        LinearLayout layout = findViewById(R.id.driving_license_layout);
        layout.setOnClickListener(this);

        layout = findViewById(R.id.cadastre_layout);
        layout.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Intent intent = null;
        switch (v.getId()) {
            case R.id.driving_license_layout:
                intent = new Intent(this, InputActivity.class);
                break;

            case R.id.cadastre_layout:
                intent = new Intent(this, CadastreMainActivity.class);
                break;
        }

        // TODO: 31/01/19 checking the technical card reading service
        //intent = new Intent(this, TechCardActivity.class);
        startActivity(intent);
    }
}

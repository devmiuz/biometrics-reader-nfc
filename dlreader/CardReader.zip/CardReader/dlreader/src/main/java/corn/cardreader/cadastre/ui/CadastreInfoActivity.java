package corn.cardreader.cadastre.ui;

import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import corn.cardreader.R;
import corn.cardreader.cadastre.CadastreListItem;
import corn.cardreader.model.BundleKey;
import corn.cardreader.ui.BaseActivity;

public class CadastreInfoActivity extends BaseActivity {

    private static final String TAG = CadastreInfoActivity.class.getName();

    private CadastreInfoFragment cadastreFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastre);

        init();
    }

    private void init() {
        initUI();

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        cadastreFragment = new CadastreInfoFragment();
        cadastreFragment.setArguments(getIntent().getExtras());

        fragmentTransaction.add(R.id.content_fragment, cadastreFragment);

        fragmentTransaction.commit();
    }

    private void initUI() {}
}

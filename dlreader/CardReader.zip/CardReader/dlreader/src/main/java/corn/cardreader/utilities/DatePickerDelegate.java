package corn.cardreader.utilities;

public interface DatePickerDelegate {

    void updateDate(int editTextID, int year, int month, int day);
}

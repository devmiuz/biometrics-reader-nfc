package corn.cardreader.storage;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import corn.cardreader.cadastre.CadastreDG1File;

import java.util.ArrayList;
import java.util.List;

@Dao
public interface CadastreDAO {

    @Insert
    void insert(CadastreDG1File cadastre);

    @Query("DELETE from cadastre WHERE ID = :cadastreID")
    void delete(long cadastreID);

    @Query("SELECT * from cadastre")
    LiveData<List<CadastreDG1File>> loadAllCadastres();

    // TODO: 04/02/19 select cadastre by ID implement
    @Query("SELECT * from cadastre WHERE ID = :ID")
    LiveData<CadastreDG1File> selectByCadastreByID(long ID);
}

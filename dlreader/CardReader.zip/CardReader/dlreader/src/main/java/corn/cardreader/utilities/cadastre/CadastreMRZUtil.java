package corn.cardreader.utilities.cadastre;

import corn.cardreader.cadastre.CadastreDG1File;
import corn.cardreader.utilities.BitConverter;
import corn.cardreader.utilities.MRZUtil;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;

public class CadastreMRZUtil {

    private static final String objtype = "type";
    private static final String areaCadNum = "areaCadNum";
    private static final String buildingCadNum = "buildingCadNum";
    private static final String address = "address";
    private static final String area = "area";
    private static final String cadValue = "cadValue";
    private static final String regDateAndNum = "regInfo";
    private static final String owner = "owner";
    private static final String passportInfo = "passportInfo";
    private static final String taxpayer = "taxpayer";
    private static final String legalDoc = "legalDoc";
    private static final String legalForm = "legalForm";
    private static final String ownershipPortion = "ownershipPortion";
    private static final String restriction = "restriction";

    private static final String TAG = CadastreMRZUtil.class.getName();

    public static CadastreDG1File parseDG1(byte[] DG1) {
        HashMap<String, String> dict = ParseVR(DG1);

        String objType = dict.get(objtype);
        String areaCadNum = dict.get(CadastreMRZUtil.areaCadNum);
        String buildingCadNum = dict.get(CadastreMRZUtil.buildingCadNum);
        String address = dict.get(CadastreMRZUtil.address);
        String area = dict.get(CadastreMRZUtil.area);
        String cadValue = dict.get(CadastreMRZUtil.cadValue);
        String regDateAndNum = dict.get(CadastreMRZUtil.regDateAndNum);
        String owner = dict.get(CadastreMRZUtil.owner);
        String passport = dict.get(CadastreMRZUtil.passportInfo);
        String taxpayer = dict.get(CadastreMRZUtil.taxpayer);
        String legalDoc = dict.get(CadastreMRZUtil.legalDoc);
        String legalForm = dict.get(CadastreMRZUtil.legalForm);
        String ownershipPortion = dict.get(CadastreMRZUtil.ownershipPortion);

        CadastreDG1File dg1File = new CadastreDG1File(objType, areaCadNum, buildingCadNum, address, area, cadValue, regDateAndNum, owner,
                passport, taxpayer, legalDoc, legalForm, ownershipPortion);

        return dg1File;
    }

    public static String ConvertByte2MetaInfoCode(byte code) {
        String retbyte = "";

        switch (code) {
            case (byte) 0xA1:
                retbyte = objtype;
                break;
            case (byte) 0xA2:
                retbyte = areaCadNum;
                break;
            case (byte) 0xA3:
                retbyte = buildingCadNum;
                break;
            case (byte) 0xA4:
                retbyte = address;
                break;
            case (byte) 0xA5:
                retbyte = area;
                break;
            case (byte) 0xA6:
                retbyte = cadValue;
                break;
            case (byte) 0xA7:
                retbyte = regDateAndNum;
                break;
            case (byte) 0xA8:
                retbyte = owner;
                break;
            case (byte) 0xA9:
                retbyte = passportInfo;
                break;

            ////////////////////////////////////////////////////////
            case (byte) 0xB1:
                retbyte = taxpayer;
                break;
            case (byte) 0xB2:
                retbyte = legalDoc;
                break;
            case (byte) 0xB3:
                retbyte = legalForm;
                break;
            case (byte) 0xB4:
                retbyte = ownershipPortion;
                break;
            case (byte) 0xB5:
                retbyte = restriction;
                break;
            case (byte) 0xB6:
                retbyte = "B6";
                break;
            case (byte) 0xB7:
                retbyte = "B7";
                break;
            case (byte) 0xB8:
                retbyte = "B8";
                break;
            case (byte) 0xB9:
                retbyte = "B9";
                break;

            ////////////////////////////////////////////////////////
            case (byte) 0xC1:
                retbyte = "C1";
                break;
            case (byte) 0xC2:
                retbyte = "C2";
                break;
            case (byte) 0xC3:
                retbyte = "C3";
                break;
            case (byte) 0xC4:
                retbyte = "C4";
                break;
            case (byte) 0xC5:
                retbyte = "C5";
                break;
            case (byte) 0xC6:
                retbyte = "C6";
                break;
            case (byte) 0xC7:
                retbyte = "C7";
                break;
            case (byte) 0xC8:
                retbyte = "C8";
                break;
            case (byte) 0xC9:
                retbyte = "C9";
                break;

            ////////////////////////////////////////////////////////
            case (byte) 0xD1:
                retbyte = "D1";
                break;
            case (byte) 0xD2:
                retbyte = "D2";
                break;
            case (byte) 0xD3:
                retbyte = "D3";
                break;
            case (byte) 0xD4:
                retbyte = "D4";
                break;
            case (byte) 0xD5:
                retbyte = "D5";
                break;
            case (byte) 0xD6:
                retbyte = "D6";
                break;
            case (byte) 0xD7:
                retbyte = "D7";
                break;
            case (byte) 0xD8:
                retbyte = "D8";
                break;
            case (byte) 0xD9:
                retbyte = "D9";
                break;

            ////////////////////////////////////////////////////////
            case (byte) 0xE1:
                retbyte = "E1";
                break;
            case (byte) 0xE2:
                retbyte = "E2";
                break;
            case (byte) 0xE3:
                retbyte = "E3";
                break;
            case (byte) 0xE4:
                retbyte = "E4";
                break;
            case (byte) 0xE5:
                retbyte = "E5";
                break;
            case (byte) 0xE6:
                retbyte = "E6";
                break;
            case (byte) 0xE7:
                retbyte = "E7";
                break;
            case (byte) 0xE8:
                retbyte = "E8";
                break;
            case (byte) 0xE9:
                retbyte = "E9";
                break;

            ////////////////////////////////////////////////////////
            case (byte) 0xF1:
                retbyte = "F1";
                break;
            case (byte) 0xF2:
                retbyte = "F2";
                break;
            case (byte) 0xF3:
                retbyte = "F3";
                break;
            case (byte) 0xF4:
                retbyte = "F4";
                break;
            case (byte) 0xF5:
                retbyte = "F5";
                break;
            case (byte) 0xF6:
                retbyte = "F6";
                break;
            case (byte) 0xF7:
                retbyte = "F7";
                break;
            case (byte) 0xF8:
                retbyte = "F8";
                break;
            case (byte) 0xF9:
                retbyte = "F9";
                break;
        }

        return retbyte;
    }

    public static HashMap<String, String> ParseVR(byte[] Vr) {
        if (Vr.length == 0) return null;

        HashMap<String, String> resDict = new HashMap<>();

        byte[] TrimmedVr = MRZUtil.decode(Vr);
        String ResultinStr = MRZUtil.ByteArrayToString(TrimmedVr);

        int StartReadNumber = 4;

        if ((TrimmedVr[1] & 0xFF) == 0x81) {
            StartReadNumber = 3;
        } else if ((TrimmedVr[1] & 0xFF) == 0x82) {
            StartReadNumber = 4;
        } else {
            StartReadNumber = 2;
        }

        boolean valueCountingBegin = false;
        boolean tagGetting = true;
        boolean lengthGetting = false;
        boolean valueCountingFinished = false;

        byte tag = 0x00;
        byte[] value = null;
        int length = 0;
        int endOfValue = 0;

        for (int j = 0; j < TrimmedVr.length - StartReadNumber; j++) {
            //Action
            if (tagGetting) {
                tag = TrimmedVr[j + StartReadNumber];
            } else if (lengthGetting) {
                byte[] lenArray = new byte[4];

                lenArray[0] = TrimmedVr[j + StartReadNumber];

                length = BitConverter.toInt32(lenArray, 0);

                if (length == 0) {
                    lengthGetting = false;
                    tagGetting = false;
                    valueCountingBegin = false;
                    valueCountingFinished = true;
                }

            } else if (valueCountingBegin) {

                value = new byte[length];

                if (((j + StartReadNumber) + length) > TrimmedVr.length) {
                    //
                    length = TrimmedVr.length - (j + StartReadNumber);
                    System.arraycopy(TrimmedVr, j + StartReadNumber, value, 0, length);
                } else {
                    System.arraycopy(TrimmedVr, j + StartReadNumber, value, 0, length);
                }

                //SetData(tag, value);
                String tagStr = ConvertByte2MetaInfoCode(tag);
                String valueStr = new String(value, StandardCharsets.UTF_8);
                resDict.put(tagStr, valueStr);

                endOfValue = j + StartReadNumber + length - 1;

                if ((j + StartReadNumber) >= endOfValue) {
                    lengthGetting = false;
                    tagGetting = true;
                    valueCountingBegin = false;
                    valueCountingFinished = false;

                    tag = 0x00;
                    value = null;
                    length = 0;
                    endOfValue = 0;

                    continue;
                }

            } else if (valueCountingFinished) {
                if ((j + StartReadNumber) >= endOfValue) {
                    tag = 0x00;
                    value = null;
                    length = 0;
                    endOfValue = 0;
                } else {
                    continue;
                }
            }


            //Setting
            if (tagGetting) {
                lengthGetting = true;
                tagGetting = false;
                valueCountingBegin = false;
                valueCountingFinished = false;
            } else if (lengthGetting) {
                lengthGetting = false;
                tagGetting = false;
                valueCountingBegin = true;
                valueCountingFinished = false;
            } else if (valueCountingBegin) {
                lengthGetting = false;
                tagGetting = false;
                valueCountingBegin = false;
                valueCountingFinished = true;
            } else if (valueCountingFinished) {
                lengthGetting = false;
                tagGetting = true;
                valueCountingBegin = false;
                valueCountingFinished = false;
            }
        }

        return resDict;
    }

}
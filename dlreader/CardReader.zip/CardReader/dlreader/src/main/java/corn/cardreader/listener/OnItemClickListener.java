package corn.cardreader.listener;

import android.view.View;
import corn.cardreader.cadastre.CadastreListItem;

public interface OnItemClickListener {

    void onItemClick(CadastreListItem item);

    void onMoreClick(CadastreListItem item, View view);

}
